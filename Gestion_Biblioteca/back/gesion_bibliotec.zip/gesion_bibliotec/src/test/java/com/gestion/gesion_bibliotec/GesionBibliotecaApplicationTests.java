package com.gestion.gesion_bibliotec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GesionBibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
