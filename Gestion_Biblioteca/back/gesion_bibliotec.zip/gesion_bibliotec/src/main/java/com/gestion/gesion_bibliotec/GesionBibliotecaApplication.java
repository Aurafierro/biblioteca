package com.gestion.gesion_bibliotec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GesionBibliotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GesionBibliotecaApplication.class, args);
	}

}
